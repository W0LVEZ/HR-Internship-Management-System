import { Outlet } from "react-router-dom";
import Sidebar from "../../../../common/components/layout/Sidebar";
import { navigation } from "../../../../common/config/navigation";

export default function ApplicantLayout() {
  const userRole = "applicant"; // This should ideally come from auth context or state management

  //Get the logged in applicant
  // Later this should come from the auth/login
  const applicant = JSON.parse(localStorage.getItem("currentApplicant")) || {};

  const fullName = `${applicant.firstName || ""} ${applicant.lastName || ""}`;

  return (
    <div className="flex">
      {/* Sidebar should always be visible*/}
      <Sidebar
        links={navigation[userRole]}
        role="Applicant"
        userName={fullName}
      />{" "}
      {/* Temp Sidebar Profile Name & Role */}
      {/* Main content area */}
      <div className="ml-60 p-6 flex-1">
        <Outlet />
      </div>
    </div>
  );
}
